﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Lucene.Net.Documents;
using Lucene.Net.Search;

namespace EduSearch
{
    public partial class MainForm : Form
    {
        SearchApp mySearchApp;
        TopDocs results;
        string saveDir;
        int pageNum;
        int numPages;
        int searchCount;

        const string DOCID_FN = "DocID";
        const string TITLE_FN = "Title";
        const string AUTHOR_FN = "Author";
        const string BIBLIOINFO_FN = "Bibliographic Information";
        const string TEXT_FN = "Text";
        const string PATH_FN = "path";

        const string Q0 = "Q0";
        const string GROUP_NAME = "N9898794_Group";


        public MainForm(SearchApp indexedMySearchApp)
        {
            mySearchApp = indexedMySearchApp;
            InitializeComponent();

        }


        private void bibloSearchButton_Click(object sender, EventArgs e)
        {
            results = mySearchApp.SearchBiblo(BibloSearchTextBox.Text);

            //Display Time
            preTimeLabel.Text = "Pre-process Time: " + mySearchApp.preprocessTime.ToString();
            searchTimeLabel.Text = "Search Time: " + mySearchApp.searchTime.ToString();

            //Display query
            queryLabel.Text = mySearchApp.query.ToString();

            //initial page Number
            pageNum = 1;

            //calculate number of pages
            numDocsLabel.Text = results.TotalHits.ToString();
            numPages = (results.TotalHits / 10) + 1;

            DisplayPages();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            mySearchApp.SetupSearcher();
        }

        private void metaSearchButton_Click(object sender, EventArgs e)
        {
            results = mySearchApp.SearchText(metaSearchTextbox.Text);

            //Display Time
            preTimeLabel.Text = "Pre-process Time: " + mySearchApp.preprocessTime.ToString();
            searchTimeLabel.Text = "Search Time: " + mySearchApp.searchTime.ToString();

            //Display query
            queryLabel.Text = mySearchApp.query.ToString();

            //initial page Number
            pageNum = 1;
            
            //calculate number of pages
            numDocsLabel.Text = results.TotalHits.ToString();
            numPages = (results.TotalHits / 10) + 1;

            DisplayPages();
        }

        private void titleSearchbutton_Click(object sender, EventArgs e)
        {
            results = mySearchApp.SearchTitle(titleSearchTextBox.Text);

            //Display Time
            preTimeLabel.Text = "Pre-process Time: " + mySearchApp.preprocessTime.ToString();
            searchTimeLabel.Text = "Search Time: " + mySearchApp.searchTime.ToString();

            //Display query
            queryLabel.Text = mySearchApp.query.ToString();

            //initial page Number
            pageNum = 1;

            //calculate number of pages
            numDocsLabel.Text = results.TotalHits.ToString();
            numPages = (results.TotalHits / 10) + 1;

            DisplayPages();
        }

        private void authorSearchButton_Click(object sender, EventArgs e)
        {
            results = mySearchApp.SearchAuthor(authorSearchTextBox.Text);

            //Display Time
            preTimeLabel.Text = "Pre-process Time: " + mySearchApp.preprocessTime.ToString();
            searchTimeLabel.Text = "Search Time: " + mySearchApp.searchTime.ToString();

            //Display query
            queryLabel.Text = mySearchApp.query.ToString();

            //initial page Number
            pageNum = 1;

            //calculate number of pages
            numDocsLabel.Text = results.TotalHits.ToString();
            numPages = (results.TotalHits / 10) + 1;

            DisplayPages();
        }

        private void DisplayPages()
        {
            //Clear Grid view
            dataGridView1.Rows.Clear();
            dataGridView1.Refresh();

            //Update page label
            pageLabel.Text = "page " + pageNum.ToString() + " From " + numPages.ToString();

            int start = ((pageNum - 1) * 10);
            for (int rank = start + 1; rank <= start + 10 && rank <= results.TotalHits; rank++)
            {
                Lucene.Net.Documents.Document doc = mySearchApp.searcher.Doc(results.ScoreDocs[rank-1].Doc);

                //Split the first sentences to display
                string firstSen = SplitFirstSen(doc.Get(TEXT_FN).ToString()) + '.'; 

                string[] aRecord =
                {   rank.ToString(),
                    doc.Get(DOCID_FN).ToString(),
                    doc.Get(TITLE_FN).ToString(),
                    doc.Get(AUTHOR_FN).ToString(),
                    doc.Get(BIBLIOINFO_FN).ToString(),
                    firstSen
                     };


                this.dataGridView1.Rows.Add(aRecord);

            }
        }

        //Split the first sentence of a text
        private string SplitFirstSen (string text)
        {
            string[] sentences = text.Split('.');
            return sentences[0];
        }

        private void nextButton_Click(object sender, EventArgs e)
        {
            if (pageNum < numPages)
            {
                pageNum++;

                //Update Grid view
                DisplayPages();

            }
        }

        private void perviousButton_Click(object sender, EventArgs e)
        {
            if (pageNum > 1)
            {
                pageNum--;

                //Update Grid view
                DisplayPages();

            }
        }

        private void retrieveButton_Click(object sender, EventArgs e)
        {
            int rank = 0;
            if (dataGridView1.SelectedRows.Count == 1)
            {
                rank = int.Parse(dataGridView1.SelectedCells[0].Value.ToString());
            }
            Lucene.Net.Documents.Document doc = mySearchApp.searcher.Doc(results.ScoreDocs[rank - 1].Doc);
            System.Diagnostics.Process.Start(doc.Get(PATH_FN).ToString());

        }

        private void browseColButton_Click(object sender, EventArgs e)
        {
            colOpenFileDialog.ShowDialog();
            string dataDir = colOpenFileDialog.FileName;
            colPathTextBox.Text = dataDir;
        }

        private void searchColButton_Click(object sender, EventArgs e)
        {
            //Read file and pre-processing
            Dictionary<string, string> queriesColl = new Dictionary<string, string>();
            string text = ReadFile(colPathTextBox.Text);

            //Open Save forms
            collSaveFileDialog.ShowDialog();
            saveDir = collSaveFileDialog.FileName;

            queriesColl = PreProcess(text);

            StreamWriter outputFile = new StreamWriter(saveDir);

            //Search and Save
            TimeSpan totalSearchTime = new TimeSpan();
            TimeSpan totalPreTime = new TimeSpan();

            foreach (KeyValuePair<string, string> item in queriesColl)
            {
                results = mySearchApp.SearchText(item.Value);

                totalSearchTime += mySearchApp.searchTime;
                totalPreTime += mySearchApp.preprocessTime;

                int rank = 0;
                foreach (ScoreDoc scoreDoc in results.ScoreDocs)
                {
                    rank++;
                    Lucene.Net.Documents.Document doc = mySearchApp.searcher.Doc(scoreDoc.Doc);
                    string docID = doc.Get(DOCID_FN).ToString();
                    string score = scoreDoc.Score.ToString();


                    string line = item.Key.ToString() + "\t" +
                                  Q0 + "\t" +
                                  docID + "\t" +
                                  rank.ToString() + "\t" +
                                  score + "\t" +
                                  GROUP_NAME;
                    outputFile.WriteLine(line);

                }

            }

            outputFile.Close();
            preTimeLabel.Text = "Pre-process Time: " + totalPreTime.ToString();
            searchTimeLabel.Text = "Search Time: " + totalSearchTime.ToString();
        }

        private string ReadFile(string name)
        {
            System.IO.StreamReader reader = new System.IO.StreamReader(name);
            string text = reader.ReadToEnd();
            reader.Close();
            return text;
        }

        private Dictionary<string,string> PreProcess(string text)
        {
            Dictionary<string, string> queriesColl = new Dictionary<string, string>();
            string[] tags = { ".I", ".D"};
            string[] sections = text.Split(tags, StringSplitOptions.RemoveEmptyEntries);
            for (int i = 0; i < sections.Count(); i += 2)
            {
                queriesColl.Add( (sections[i].Replace("\n", String.Empty)).ToLower(),
                (sections[i+1].Replace("\n", String.Empty)).ToLower());
            }

            return queriesColl;
        }

        private void saveButton_Click(object sender, EventArgs e)
        {
            //Open Save forms
            collSaveFileDialog.ShowDialog();
            saveDir = collSaveFileDialog.FileName;

            StreamWriter outputFile = new StreamWriter(saveDir);

            int rank = 0;
            searchCount = 1;
            foreach (ScoreDoc scoreDoc in results.ScoreDocs)
            {
                rank++;
                Lucene.Net.Documents.Document doc = mySearchApp.searcher.Doc(scoreDoc.Doc);
                string docID = doc.Get(DOCID_FN).ToString();
                string score = scoreDoc.Score.ToString();


                string line = searchCount.ToString("000") + "\t" +
                              Q0 + "\t" +
                              docID + "\t" +
                              rank.ToString() + "\t" +
                              score + "\t" +
                              GROUP_NAME;
                outputFile.WriteLine(line);

            }

            outputFile.Close();
        }

        private void addResultButton_Click(object sender, EventArgs e)
        {
            if (saveDir != null)
            { 
                StreamWriter outputFile = File.AppendText(saveDir);

                int rank = 0;
                searchCount++;

                foreach (ScoreDoc scoreDoc in results.ScoreDocs)
                {
                    rank++;
                    Lucene.Net.Documents.Document doc = mySearchApp.searcher.Doc(scoreDoc.Doc);
                    string docID = doc.Get(DOCID_FN).ToString();
                    string score = scoreDoc.Score.ToString();


                    string line = searchCount.ToString("000") + "\t" +
                                  Q0 + "\t" +
                                  docID + "\t" +
                                  rank.ToString() + "\t" +
                                  score + "\t" +
                                  GROUP_NAME;
                    outputFile.WriteLine(line);

                }

                outputFile.Close();
            }
        }

        private void metaSearchTextbox_TextChanged(object sender, EventArgs e)
        {

        }

        private void searchAllButton_Click(object sender, EventArgs e)
        {


            //Query expansion
            string words = searchAllTextBox.Text + "^5";
            var expQuery = mySearchApp.wordNet.GetSynSets(searchAllTextBox.Text);

            if (queryExpCheckBox.Checked == true &&  (expQuery.Count > 0))
            {
                foreach (var word in expQuery)
                {
                    string synwords = string.Join(" ", word.Words);
                    synwords = synwords.Replace(searchAllTextBox.Text, "");
                    words = words + " " + synwords;
                }
            }


            if (preProcessCheckBox.Checked == true)
            {
                results = mySearchApp.SearchAll(words);
            }
            else
            {
                results = mySearchApp.SearchNoPreAll(words);
            }

            //Display Time
            preTimeLabel.Text = "Pre-process Time: " + mySearchApp.preprocessTime.ToString();
            searchTimeLabel.Text = "Search Time: " + mySearchApp.searchTime.ToString();

            //Display query

            if (queryExpCheckBox.Checked == true)
            {
                System.Windows.Forms.MessageBox.Show(words);
            }
            else
            {
                queryLabel.Text = mySearchApp.query.ToString();
            }

            //initial page Number
            pageNum = 1;

            //calculate number of pages
            numDocsLabel.Text = results.TotalHits.ToString();
            numPages = (results.TotalHits / 10) + 1;

            DisplayPages();
        }
    }
}
