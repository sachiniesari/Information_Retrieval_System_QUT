﻿namespace EduSearch
{
    partial class ImportForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.indexTextBox = new System.Windows.Forms.TextBox();
            this.importTextBox = new System.Windows.Forms.TextBox();
            this.buttonDone = new System.Windows.Forms.Button();
            this.buttonSaveIndex = new System.Windows.Forms.Button();
            this.buttonImport = new System.Windows.Forms.Button();
            this.labelSaveIndex = new System.Windows.Forms.Label();
            this.labelImportData = new System.Windows.Forms.Label();
            this.folderBrowserDialogImport = new System.Windows.Forms.FolderBrowserDialog();
            this.saveFileDialog1 = new System.Windows.Forms.SaveFileDialog();
            this.SuspendLayout();
            // 
            // indexTextBox
            // 
            this.indexTextBox.Location = new System.Drawing.Point(192, 67);
            this.indexTextBox.Name = "indexTextBox";
            this.indexTextBox.Size = new System.Drawing.Size(293, 20);
            this.indexTextBox.TabIndex = 13;
            // 
            // importTextBox
            // 
            this.importTextBox.Location = new System.Drawing.Point(192, 28);
            this.importTextBox.Name = "importTextBox";
            this.importTextBox.Size = new System.Drawing.Size(293, 20);
            this.importTextBox.TabIndex = 12;
            // 
            // buttonDone
            // 
            this.buttonDone.Location = new System.Drawing.Point(208, 111);
            this.buttonDone.Name = "buttonDone";
            this.buttonDone.Size = new System.Drawing.Size(75, 23);
            this.buttonDone.TabIndex = 11;
            this.buttonDone.Text = "Start";
            this.buttonDone.UseVisualStyleBackColor = true;
            this.buttonDone.Click += new System.EventHandler(this.buttonDone_Click);
            // 
            // buttonSaveIndex
            // 
            this.buttonSaveIndex.Location = new System.Drawing.Point(111, 65);
            this.buttonSaveIndex.Name = "buttonSaveIndex";
            this.buttonSaveIndex.Size = new System.Drawing.Size(75, 23);
            this.buttonSaveIndex.TabIndex = 10;
            this.buttonSaveIndex.Text = "Browse";
            this.buttonSaveIndex.UseVisualStyleBackColor = true;
            this.buttonSaveIndex.Click += new System.EventHandler(this.buttonSaveIndex_Click);
            // 
            // buttonImport
            // 
            this.buttonImport.Location = new System.Drawing.Point(111, 26);
            this.buttonImport.Name = "buttonImport";
            this.buttonImport.Size = new System.Drawing.Size(75, 23);
            this.buttonImport.TabIndex = 9;
            this.buttonImport.Text = "Brows";
            this.buttonImport.UseVisualStyleBackColor = true;
            this.buttonImport.Click += new System.EventHandler(this.buttonImport_Click);
            // 
            // labelSaveIndex
            // 
            this.labelSaveIndex.AutoSize = true;
            this.labelSaveIndex.Location = new System.Drawing.Point(18, 70);
            this.labelSaveIndex.Name = "labelSaveIndex";
            this.labelSaveIndex.Size = new System.Drawing.Size(57, 13);
            this.labelSaveIndex.TabIndex = 8;
            this.labelSaveIndex.Text = "Index path";
            // 
            // labelImportData
            // 
            this.labelImportData.AutoSize = true;
            this.labelImportData.Location = new System.Drawing.Point(18, 31);
            this.labelImportData.Name = "labelImportData";
            this.labelImportData.Size = new System.Drawing.Size(93, 13);
            this.labelImportData.TabIndex = 7;
            this.labelImportData.Text = "Dataset Collection";
            // 
            // ImportForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(508, 159);
            this.Controls.Add(this.indexTextBox);
            this.Controls.Add(this.importTextBox);
            this.Controls.Add(this.buttonDone);
            this.Controls.Add(this.buttonSaveIndex);
            this.Controls.Add(this.buttonImport);
            this.Controls.Add(this.labelSaveIndex);
            this.Controls.Add(this.labelImportData);
            this.Name = "ImportForm";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.ImportForm_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox indexTextBox;
        private System.Windows.Forms.TextBox importTextBox;
        private System.Windows.Forms.Button buttonDone;
        private System.Windows.Forms.Button buttonSaveIndex;
        private System.Windows.Forms.Button buttonImport;
        private System.Windows.Forms.Label labelSaveIndex;
        private System.Windows.Forms.Label labelImportData;
        private System.Windows.Forms.FolderBrowserDialog folderBrowserDialogImport;
        private System.Windows.Forms.SaveFileDialog saveFileDialog1;
    }
}

