﻿namespace EduSearch
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.perviousButton = new System.Windows.Forms.Button();
            this.nextButton = new System.Windows.Forms.Button();
            this.pageLabel = new System.Windows.Forms.Label();
            this.numDocsLabel = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.metaSearchButton = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.rankCol = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.docIDCol = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.titleCol = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.authorCol = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bibloCol = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.abstractCol = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Searchlabel = new System.Windows.Forms.Label();
            this.metaSearchTextbox = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.titleSearchTextBox = new System.Windows.Forms.TextBox();
            this.titleSearchbutton = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.authorSearchTextBox = new System.Windows.Forms.TextBox();
            this.authorSearchButton = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.BibloSearchTextBox = new System.Windows.Forms.TextBox();
            this.bibloSearchButton = new System.Windows.Forms.Button();
            this.retrieveButton = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.queryLabel = new System.Windows.Forms.Label();
            this.preProcessCheckBox = new System.Windows.Forms.CheckBox();
            this.preTimeLabel = new System.Windows.Forms.Label();
            this.searchTimeLabel = new System.Windows.Forms.Label();
            this.browseColButton = new System.Windows.Forms.Button();
            this.nextSearchColButton = new System.Windows.Forms.Button();
            this.saveButton = new System.Windows.Forms.Button();
            this.colPathTextBox = new System.Windows.Forms.TextBox();
            this.collSaveFileDialog = new System.Windows.Forms.SaveFileDialog();
            this.colOpenFileDialog = new System.Windows.Forms.OpenFileDialog();
            this.addResultButton = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.searchAllTextBox = new System.Windows.Forms.TextBox();
            this.searchAllButton = new System.Windows.Forms.Button();
            this.queryExpCheckBox = new System.Windows.Forms.CheckBox();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // perviousButton
            // 
            this.perviousButton.Location = new System.Drawing.Point(389, 542);
            this.perviousButton.Name = "perviousButton";
            this.perviousButton.Size = new System.Drawing.Size(93, 23);
            this.perviousButton.TabIndex = 17;
            this.perviousButton.Text = "Pervious Page";
            this.perviousButton.UseVisualStyleBackColor = true;
            this.perviousButton.Click += new System.EventHandler(this.perviousButton_Click);
            // 
            // nextButton
            // 
            this.nextButton.Location = new System.Drawing.Point(614, 542);
            this.nextButton.Name = "nextButton";
            this.nextButton.Size = new System.Drawing.Size(93, 23);
            this.nextButton.TabIndex = 16;
            this.nextButton.Text = "Next Page";
            this.nextButton.UseVisualStyleBackColor = true;
            this.nextButton.Click += new System.EventHandler(this.nextButton_Click);
            // 
            // pageLabel
            // 
            this.pageLabel.AutoSize = true;
            this.pageLabel.Location = new System.Drawing.Point(514, 547);
            this.pageLabel.Name = "pageLabel";
            this.pageLabel.Size = new System.Drawing.Size(73, 13);
            this.pageLabel.TabIndex = 15;
            this.pageLabel.Text = "Page 0 from 0";
            // 
            // numDocsLabel
            // 
            this.numDocsLabel.AutoSize = true;
            this.numDocsLabel.Location = new System.Drawing.Point(182, 254);
            this.numDocsLabel.Name = "numDocsLabel";
            this.numDocsLabel.Size = new System.Drawing.Size(13, 13);
            this.numDocsLabel.TabIndex = 14;
            this.numDocsLabel.Text = "0";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(17, 254);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(159, 13);
            this.label1.TabIndex = 13;
            this.label1.Text = "Number of founded documents: ";
            // 
            // metaSearchButton
            // 
            this.metaSearchButton.Location = new System.Drawing.Point(442, 66);
            this.metaSearchButton.Name = "metaSearchButton";
            this.metaSearchButton.Size = new System.Drawing.Size(75, 23);
            this.metaSearchButton.TabIndex = 12;
            this.metaSearchButton.Text = "Search";
            this.metaSearchButton.UseVisualStyleBackColor = true;
            this.metaSearchButton.Click += new System.EventHandler(this.metaSearchButton_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.rankCol,
            this.docIDCol,
            this.titleCol,
            this.authorCol,
            this.bibloCol,
            this.abstractCol});
            this.dataGridView1.Location = new System.Drawing.Point(16, 273);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.Size = new System.Drawing.Size(1058, 263);
            this.dataGridView1.TabIndex = 11;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // rankCol
            // 
            this.rankCol.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.rankCol.HeaderText = "Rank";
            this.rankCol.Name = "rankCol";
            this.rankCol.ReadOnly = true;
            this.rankCol.Width = 58;
            // 
            // docIDCol
            // 
            this.docIDCol.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.docIDCol.HeaderText = "Document ID";
            this.docIDCol.Name = "docIDCol";
            this.docIDCol.ReadOnly = true;
            this.docIDCol.Width = 95;
            // 
            // titleCol
            // 
            this.titleCol.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.titleCol.HeaderText = "Title";
            this.titleCol.Name = "titleCol";
            this.titleCol.ReadOnly = true;
            this.titleCol.Width = 52;
            // 
            // authorCol
            // 
            this.authorCol.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.authorCol.HeaderText = "Author(s)";
            this.authorCol.Name = "authorCol";
            this.authorCol.ReadOnly = true;
            this.authorCol.Width = 74;
            // 
            // bibloCol
            // 
            this.bibloCol.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.bibloCol.HeaderText = "Biblographic";
            this.bibloCol.Name = "bibloCol";
            this.bibloCol.ReadOnly = true;
            this.bibloCol.Width = 90;
            // 
            // abstractCol
            // 
            this.abstractCol.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.abstractCol.HeaderText = "Abstract";
            this.abstractCol.Name = "abstractCol";
            this.abstractCol.ReadOnly = true;
            this.abstractCol.Width = 71;
            // 
            // Searchlabel
            // 
            this.Searchlabel.AutoSize = true;
            this.Searchlabel.Location = new System.Drawing.Point(13, 69);
            this.Searchlabel.Name = "Searchlabel";
            this.Searchlabel.Size = new System.Drawing.Size(168, 13);
            this.Searchlabel.TabIndex = 10;
            this.Searchlabel.Text = "Meta search (Abstracts and Titles)";
            // 
            // metaSearchTextbox
            // 
            this.metaSearchTextbox.Location = new System.Drawing.Point(193, 66);
            this.metaSearchTextbox.Name = "metaSearchTextbox";
            this.metaSearchTextbox.Size = new System.Drawing.Size(243, 20);
            this.metaSearchTextbox.TabIndex = 9;
            this.metaSearchTextbox.TextChanged += new System.EventHandler(this.metaSearchTextbox_TextChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(117, 101);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(64, 13);
            this.label2.TabIndex = 18;
            this.label2.Text = "Title Search";
            // 
            // titleSearchTextBox
            // 
            this.titleSearchTextBox.Location = new System.Drawing.Point(193, 98);
            this.titleSearchTextBox.Name = "titleSearchTextBox";
            this.titleSearchTextBox.Size = new System.Drawing.Size(243, 20);
            this.titleSearchTextBox.TabIndex = 19;
            // 
            // titleSearchbutton
            // 
            this.titleSearchbutton.Location = new System.Drawing.Point(442, 98);
            this.titleSearchbutton.Name = "titleSearchbutton";
            this.titleSearchbutton.Size = new System.Drawing.Size(75, 23);
            this.titleSearchbutton.TabIndex = 20;
            this.titleSearchbutton.Text = "Search";
            this.titleSearchbutton.UseVisualStyleBackColor = true;
            this.titleSearchbutton.Click += new System.EventHandler(this.titleSearchbutton_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(106, 133);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(75, 13);
            this.label3.TabIndex = 21;
            this.label3.Text = "Author Search";
            // 
            // authorSearchTextBox
            // 
            this.authorSearchTextBox.Location = new System.Drawing.Point(193, 130);
            this.authorSearchTextBox.Name = "authorSearchTextBox";
            this.authorSearchTextBox.Size = new System.Drawing.Size(243, 20);
            this.authorSearchTextBox.TabIndex = 22;
            // 
            // authorSearchButton
            // 
            this.authorSearchButton.Location = new System.Drawing.Point(442, 130);
            this.authorSearchButton.Name = "authorSearchButton";
            this.authorSearchButton.Size = new System.Drawing.Size(75, 23);
            this.authorSearchButton.TabIndex = 23;
            this.authorSearchButton.Text = "Search";
            this.authorSearchButton.UseVisualStyleBackColor = true;
            this.authorSearchButton.Click += new System.EventHandler(this.authorSearchButton_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(79, 164);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(102, 13);
            this.label4.TabIndex = 24;
            this.label4.Text = "Biblographic Search";
            // 
            // BibloSearchTextBox
            // 
            this.BibloSearchTextBox.Location = new System.Drawing.Point(193, 161);
            this.BibloSearchTextBox.Name = "BibloSearchTextBox";
            this.BibloSearchTextBox.Size = new System.Drawing.Size(243, 20);
            this.BibloSearchTextBox.TabIndex = 25;
            // 
            // bibloSearchButton
            // 
            this.bibloSearchButton.Location = new System.Drawing.Point(442, 161);
            this.bibloSearchButton.Name = "bibloSearchButton";
            this.bibloSearchButton.Size = new System.Drawing.Size(75, 23);
            this.bibloSearchButton.TabIndex = 26;
            this.bibloSearchButton.Text = "Search";
            this.bibloSearchButton.UseVisualStyleBackColor = true;
            this.bibloSearchButton.Click += new System.EventHandler(this.bibloSearchButton_Click);
            // 
            // retrieveButton
            // 
            this.retrieveButton.Location = new System.Drawing.Point(958, 227);
            this.retrieveButton.Name = "retrieveButton";
            this.retrieveButton.Size = new System.Drawing.Size(116, 40);
            this.retrieveButton.TabIndex = 27;
            this.retrieveButton.Text = "Retrieve selected file";
            this.retrieveButton.UseVisualStyleBackColor = true;
            this.retrieveButton.Click += new System.EventHandler(this.retrieveButton_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(842, 27);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(114, 13);
            this.label5.TabIndex = 28;
            this.label5.Text = "Select query collection";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(146, 192);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(35, 13);
            this.label6.TabIndex = 29;
            this.label6.Text = "Query";
            // 
            // queryLabel
            // 
            this.queryLabel.AutoSize = true;
            this.queryLabel.Location = new System.Drawing.Point(187, 192);
            this.queryLabel.Name = "queryLabel";
            this.queryLabel.Size = new System.Drawing.Size(75, 13);
            this.queryLabel.TabIndex = 30;
            this.queryLabel.Text = "Inputted query";
            // 
            // preProcessCheckBox
            // 
            this.preProcessCheckBox.AutoSize = true;
            this.preProcessCheckBox.Checked = true;
            this.preProcessCheckBox.CheckState = System.Windows.Forms.CheckState.Checked;
            this.preProcessCheckBox.Location = new System.Drawing.Point(545, 12);
            this.preProcessCheckBox.Name = "preProcessCheckBox";
            this.preProcessCheckBox.Size = new System.Drawing.Size(119, 17);
            this.preProcessCheckBox.TabIndex = 31;
            this.preProcessCheckBox.Text = "Pre-process queries";
            this.preProcessCheckBox.UseVisualStyleBackColor = true;
            // 
            // preTimeLabel
            // 
            this.preTimeLabel.AutoSize = true;
            this.preTimeLabel.Location = new System.Drawing.Point(234, 254);
            this.preTimeLabel.Name = "preTimeLabel";
            this.preTimeLabel.Size = new System.Drawing.Size(95, 13);
            this.preTimeLabel.TabIndex = 32;
            this.preTimeLabel.Text = "Pre-process Time: ";
            // 
            // searchTimeLabel
            // 
            this.searchTimeLabel.AutoSize = true;
            this.searchTimeLabel.Location = new System.Drawing.Point(456, 254);
            this.searchTimeLabel.Name = "searchTimeLabel";
            this.searchTimeLabel.Size = new System.Drawing.Size(73, 13);
            this.searchTimeLabel.TabIndex = 33;
            this.searchTimeLabel.Text = "Search Time: ";
            // 
            // browseColButton
            // 
            this.browseColButton.Location = new System.Drawing.Point(990, 22);
            this.browseColButton.Name = "browseColButton";
            this.browseColButton.Size = new System.Drawing.Size(75, 23);
            this.browseColButton.TabIndex = 34;
            this.browseColButton.Text = "Browse";
            this.browseColButton.UseVisualStyleBackColor = true;
            this.browseColButton.Click += new System.EventHandler(this.browseColButton_Click);
            // 
            // nextSearchColButton
            // 
            this.nextSearchColButton.Location = new System.Drawing.Point(909, 80);
            this.nextSearchColButton.Name = "nextSearchColButton";
            this.nextSearchColButton.Size = new System.Drawing.Size(117, 32);
            this.nextSearchColButton.TabIndex = 35;
            this.nextSearchColButton.Text = "Search And Save";
            this.nextSearchColButton.UseVisualStyleBackColor = true;
            this.nextSearchColButton.Click += new System.EventHandler(this.searchColButton_Click);
            // 
            // saveButton
            // 
            this.saveButton.Location = new System.Drawing.Point(714, 227);
            this.saveButton.Name = "saveButton";
            this.saveButton.Size = new System.Drawing.Size(116, 40);
            this.saveButton.TabIndex = 36;
            this.saveButton.Text = "Save results";
            this.saveButton.UseVisualStyleBackColor = true;
            this.saveButton.Click += new System.EventHandler(this.saveButton_Click);
            // 
            // colPathTextBox
            // 
            this.colPathTextBox.Location = new System.Drawing.Point(845, 53);
            this.colPathTextBox.Name = "colPathTextBox";
            this.colPathTextBox.Size = new System.Drawing.Size(220, 20);
            this.colPathTextBox.TabIndex = 37;
            // 
            // colOpenFileDialog
            // 
            this.colOpenFileDialog.FileName = "cran_information_needs.txt";
            // 
            // addResultButton
            // 
            this.addResultButton.Location = new System.Drawing.Point(836, 227);
            this.addResultButton.Name = "addResultButton";
            this.addResultButton.Size = new System.Drawing.Size(116, 40);
            this.addResultButton.TabIndex = 38;
            this.addResultButton.Text = "Add result to saved file";
            this.addResultButton.UseVisualStyleBackColor = true;
            this.addResultButton.Click += new System.EventHandler(this.addResultButton_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(81, 23);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(100, 13);
            this.label7.TabIndex = 39;
            this.label7.Text = "Search Everywhere";
            // 
            // searchAllTextBox
            // 
            this.searchAllTextBox.Location = new System.Drawing.Point(193, 16);
            this.searchAllTextBox.Name = "searchAllTextBox";
            this.searchAllTextBox.Size = new System.Drawing.Size(243, 20);
            this.searchAllTextBox.TabIndex = 40;
            // 
            // searchAllButton
            // 
            this.searchAllButton.Location = new System.Drawing.Point(442, 14);
            this.searchAllButton.Name = "searchAllButton";
            this.searchAllButton.Size = new System.Drawing.Size(75, 23);
            this.searchAllButton.TabIndex = 41;
            this.searchAllButton.Text = "Search";
            this.searchAllButton.UseVisualStyleBackColor = true;
            this.searchAllButton.Click += new System.EventHandler(this.searchAllButton_Click);
            // 
            // queryExpCheckBox
            // 
            this.queryExpCheckBox.AutoSize = true;
            this.queryExpCheckBox.Location = new System.Drawing.Point(545, 36);
            this.queryExpCheckBox.Name = "queryExpCheckBox";
            this.queryExpCheckBox.Size = new System.Drawing.Size(106, 17);
            this.queryExpCheckBox.TabIndex = 42;
            this.queryExpCheckBox.Text = "Query Expansion";
            this.queryExpCheckBox.UseVisualStyleBackColor = true;
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1082, 575);
            this.Controls.Add(this.queryExpCheckBox);
            this.Controls.Add(this.searchAllButton);
            this.Controls.Add(this.searchAllTextBox);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.addResultButton);
            this.Controls.Add(this.colPathTextBox);
            this.Controls.Add(this.saveButton);
            this.Controls.Add(this.nextSearchColButton);
            this.Controls.Add(this.browseColButton);
            this.Controls.Add(this.searchTimeLabel);
            this.Controls.Add(this.preTimeLabel);
            this.Controls.Add(this.preProcessCheckBox);
            this.Controls.Add(this.queryLabel);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.retrieveButton);
            this.Controls.Add(this.bibloSearchButton);
            this.Controls.Add(this.BibloSearchTextBox);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.authorSearchButton);
            this.Controls.Add(this.authorSearchTextBox);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.titleSearchbutton);
            this.Controls.Add(this.titleSearchTextBox);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.perviousButton);
            this.Controls.Add(this.nextButton);
            this.Controls.Add(this.pageLabel);
            this.Controls.Add(this.numDocsLabel);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.metaSearchButton);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.Searchlabel);
            this.Controls.Add(this.metaSearchTextbox);
            this.Name = "MainForm";
            this.Text = "MainForm";
            this.Load += new System.EventHandler(this.MainForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button perviousButton;
        private System.Windows.Forms.Button nextButton;
        private System.Windows.Forms.Label pageLabel;
        private System.Windows.Forms.Label numDocsLabel;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button metaSearchButton;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Label Searchlabel;
        private System.Windows.Forms.TextBox metaSearchTextbox;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox titleSearchTextBox;
        private System.Windows.Forms.Button titleSearchbutton;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox authorSearchTextBox;
        private System.Windows.Forms.Button authorSearchButton;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox BibloSearchTextBox;
        private System.Windows.Forms.Button bibloSearchButton;
        private System.Windows.Forms.DataGridViewTextBoxColumn rankCol;
        private System.Windows.Forms.DataGridViewTextBoxColumn docIDCol;
        private System.Windows.Forms.DataGridViewTextBoxColumn titleCol;
        private System.Windows.Forms.DataGridViewTextBoxColumn authorCol;
        private System.Windows.Forms.DataGridViewTextBoxColumn bibloCol;
        private System.Windows.Forms.DataGridViewTextBoxColumn abstractCol;
        private System.Windows.Forms.Button retrieveButton;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label queryLabel;
        private System.Windows.Forms.CheckBox preProcessCheckBox;
        private System.Windows.Forms.Label preTimeLabel;
        private System.Windows.Forms.Label searchTimeLabel;
        private System.Windows.Forms.Button browseColButton;
        private System.Windows.Forms.Button nextSearchColButton;
        private System.Windows.Forms.Button saveButton;
        private System.Windows.Forms.TextBox colPathTextBox;
        private System.Windows.Forms.SaveFileDialog collSaveFileDialog;
        private System.Windows.Forms.OpenFileDialog colOpenFileDialog;
        private System.Windows.Forms.Button addResultButton;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox searchAllTextBox;
        private System.Windows.Forms.Button searchAllButton;
        private System.Windows.Forms.CheckBox queryExpCheckBox;
    }
}