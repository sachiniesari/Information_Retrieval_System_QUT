﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Lucene.Net.Analysis; // for Analyser
using Lucene.Net.Analysis.Snowball;// for Snowball Analyser
using Lucene.Net.Documents; // for Socument
using Lucene.Net.Index; //for Index Writer
using Lucene.Net.Store; //for Directory
using Lucene.Net.Search; // for IndexSearcher
using Lucene.Net.QueryParsers;  // for QueryParser
using Syn.WordNet; //Wordnet
using System.IO;

namespace EduSearch
{
    public class SearchApp
    {
        Lucene.Net.Store.Directory indexDirectory;
        Lucene.Net.Analysis.PerFieldAnalyzerWrapper analyzer;
        Lucene.Net.Index.IndexWriter writer;
        public IndexSearcher searcher;
        public Query query;
        public TimeSpan preprocessTime;
        public TimeSpan searchTime;
        public Syn.WordNet.WordNetEngine wordNet;
        public string Searcher { get; set; }



        QueryParser parserTitle;
        QueryParser parserAuthor;
        QueryParser parserBiblo;
        QueryParser parserText;
        QueryParser parserTitleNoPre;
        QueryParser parserAll;
        QueryParser parserAllNoPre;


        public static Lucene.Net.Util.Version VERSION = Lucene.Net.Util.Version.LUCENE_30;
        const string DOCID_FN = "DocID";
        const string TITLE_FN = "Title"; const string TITLE_NO = "Title No Pre";
        const string AUTHOR_FN = "Author"; const string AUTHOR_NO = "Author No Pre";
        const string BIBLIOINFO_FN = "Bibliographic Information"; const string BIBLIOINFO_NO = "Bibliographic Information No Pre";
        const string TEXT_FN = "Text"; const string TEXT_NO = "Text No Pre";
        const string PATH_FN = "path";


        public SearchApp()
        {
            indexDirectory = null; // Is set in Create Index
            writer = null; // Is set in CreateWriter using simple analyser
            searcher = null; // Is set in Searcher
            parserTitle = null; parserTitleNoPre = null;  // Is set in Parser for titles
            parserAuthor = null; // Is set in Parser for authors
            parserBiblo = null; // Is set in Parser for bilbographic
            parserText = null; // Is set in Parser for abstract
            parserAll = null;// Is set in Parser for All fields
            parserAllNoPre = null;

            //Analyzers
            analyzer = new PerFieldAnalyzerWrapper(new SimpleAnalyzer());
            analyzer.AddAnalyzer(TITLE_FN, new SnowballAnalyzer(Lucene.Net.Util.Version.LUCENE_30, "English",StopWordsList.getStopWordsList()));
            analyzer.AddAnalyzer(TEXT_FN, new SnowballAnalyzer(Lucene.Net.Util.Version.LUCENE_30, "English", StopWordsList.getStopWordsList()));
            analyzer.AddAnalyzer(BIBLIOINFO_FN, new WhitespaceAnalyzer());
            analyzer.AddAnalyzer(TITLE_NO, new WhitespaceAnalyzer());
            analyzer.AddAnalyzer(AUTHOR_NO, new WhitespaceAnalyzer());
            analyzer.AddAnalyzer(BIBLIOINFO_NO, new WhitespaceAnalyzer());
            analyzer.AddAnalyzer(TEXT_NO, new WhitespaceAnalyzer());
        }

        /// <summary>
        /// Creates the index at indexPath
        /// </summary>
        /// <param name="indexPath">Directory path to create the index</param>
        public void CreateIndex(string indexPath)
        {
            indexDirectory = Lucene.Net.Store.FSDirectory.Open(indexPath);
            IndexWriter.MaxFieldLength mfl = new IndexWriter.MaxFieldLength(IndexWriter.DEFAULT_MAX_FIELD_LENGTH);
            writer = new Lucene.Net.Index.IndexWriter(indexDirectory, analyzer, true, mfl);
        }

        /// <summary>
        /// Indexes information relating to abstract of papers
        /// </summary>
        /// <param name="docID">The document's ID</param>
        /// <param name="title">The document's title</param>
        /// <param name="author">The document's author</param>
        /// <param name="biblo">The document's biblographic information</param>
        /// <param name="text">The document's abstrct</param>
        public void IndexText(Article article)
        {
            Lucene.Net.Documents.Field pathField = new Field(PATH_FN, article.FileName, Field.Store.YES, Field.Index.NO, Field.TermVector.NO);
            Lucene.Net.Documents.Field docIDField = new Field(DOCID_FN, article.DocID, Field.Store.YES, Field.Index.ANALYZED, Field.TermVector.YES);
            Lucene.Net.Documents.Field titleField = new Field(TITLE_FN, article.Title, Field.Store.YES, Field.Index.ANALYZED, Field.TermVector.YES);
            Lucene.Net.Documents.Field authorField = new Field(AUTHOR_FN, article.Author, Field.Store.YES, Field.Index.ANALYZED, Field.TermVector.YES);
            Lucene.Net.Documents.Field bibloField = new Field(BIBLIOINFO_FN, article.Biblo, Field.Store.YES, Field.Index.ANALYZED, Field.TermVector.YES);
            Lucene.Net.Documents.Field textField = new Field(TEXT_FN, article.Text, Field.Store.YES, Field.Index.ANALYZED, Field.TermVector.YES);

            //White Space Analyzer
            Lucene.Net.Documents.Field titleNoAnalyzedField = new Field(TITLE_NO, article.Title, Field.Store.YES, Field.Index.ANALYZED, Field.TermVector.YES);
            Lucene.Net.Documents.Field authorNoAnalyzedField = new Field(AUTHOR_NO, article.Author, Field.Store.YES, Field.Index.ANALYZED, Field.TermVector.YES);
            Lucene.Net.Documents.Field bibloNoAnalyzedField = new Field(BIBLIOINFO_NO, article.Biblo, Field.Store.YES, Field.Index.ANALYZED, Field.TermVector.YES);
            Lucene.Net.Documents.Field textNoAnalyzedField = new Field(TEXT_NO, article.Text, Field.Store.YES, Field.Index.ANALYZED, Field.TermVector.YES);

            Lucene.Net.Documents.Document doc = new Document();
            //Boost title field
            titleField.Boost = 2;
            authorField.Boost = 2;

            doc.Add(pathField);
            doc.Add(docIDField);
            doc.Add(titleField);
            doc.Add(authorField);
            doc.Add(bibloField);
            doc.Add(textField);
            doc.Add(titleNoAnalyzedField);
            doc.Add(authorNoAnalyzedField);
            doc.Add(bibloNoAnalyzedField);
            doc.Add(textNoAnalyzedField);
            writer.AddDocument(doc);
        }
        /// <summary>
        /// Flushes buffers and closes the index
        /// </summary>
        public void CleanUpIndexer()
        {
            writer.Optimize();
            writer.Flush(true, true, true);
            writer.Dispose();
        }

        public void SetupSearcher()
        {
            searcher = new IndexSearcher(indexDirectory);
            parserTitle = new QueryParser(Lucene.Net.Util.Version.LUCENE_30, TITLE_FN, new SnowballAnalyzer(Lucene.Net.Util.Version.LUCENE_30, "English"));
            parserAuthor = new QueryParser(Lucene.Net.Util.Version.LUCENE_30, AUTHOR_FN, new SimpleAnalyzer());
            parserBiblo = new QueryParser(Lucene.Net.Util.Version.LUCENE_30, BIBLIOINFO_FN, analyzer);
            parserText = new MultiFieldQueryParser(Lucene.Net.Util.Version.LUCENE_30, new[] { TEXT_FN, TITLE_FN }, new SnowballAnalyzer(Lucene.Net.Util.Version.LUCENE_30, "English"));
            parserAll = new MultiFieldQueryParser(Lucene.Net.Util.Version.LUCENE_30, new[] { TEXT_FN, TITLE_FN, AUTHOR_FN, BIBLIOINFO_FN }, analyzer);
            parserAllNoPre = new MultiFieldQueryParser(Lucene.Net.Util.Version.LUCENE_30, new[] { TEXT_NO, TITLE_NO, AUTHOR_NO, BIBLIOINFO_NO }, analyzer);
        }

        public void CleanUpSearcher()
        {
            searcher.Dispose();
        }

        //Read all files from a directory
        public Dictionary<string,string> WalkDirectoryTree(String path)
        {
            System.IO.DirectoryInfo root = new System.IO.DirectoryInfo(path);
            System.IO.FileInfo[] files = null;
            System.IO.DirectoryInfo[] subDirs = null;

            Dictionary<string, string> filesList = new Dictionary<string, string>();

            // First, process all the files directly under this folder 
            try
            {
                files = root.GetFiles("*.*");
            }

            catch (UnauthorizedAccessException e)
            {
                System.Console.WriteLine(e.Message);
            }

            catch (System.IO.DirectoryNotFoundException e)
            {
                Console.WriteLine(e.Message);
            }

            if (files != null)
            {
                foreach (System.IO.FileInfo fi in files)
                {
                    string name = fi.FullName;
                    string text = ReadFile(name);
                    filesList.Add(name,text);
                }

                // Now find all the subdirectories under this directory.
                subDirs = root.GetDirectories();

                foreach (System.IO.DirectoryInfo dirInfo in subDirs)
                {
                    // Resursive call for each subdirectory.
                    string name = dirInfo.FullName;
                    WalkDirectoryTree(name);
                }
            }

            return filesList;
        }

        public string ReadFile(string name)
        {
            System.IO.StreamReader reader = new System.IO.StreamReader(name);
            string text = reader.ReadToEnd();
            reader.Close();
            return text;
        }

        //Index collection
        public TimeSpan[] Indexig(string datasetPath, string indexPath)
        {
            //List of articles
            List<Article> articles = new List<Article>();
            this.CreateIndex(indexPath);


            DateTime start = System.DateTime.Now;
            Dictionary<string,string> textList = WalkDirectoryTree(datasetPath);
            DateTime endReadingfiles = System.DateTime.Now;

            //pre-processing
            foreach (KeyValuePair<string, string> item in textList)
            {
                articles.Add(new Article(item.Key, item.Value));
            }
            DateTime endPrePrcess = System.DateTime.Now;

            foreach (Article oneArticle in articles)
            {
                this.IndexText(oneArticle);
            }

            // clean up
            this.CleanUpIndexer();
            DateTime endIndexing = System.DateTime.Now;

            TimeSpan[] times = { endReadingfiles - start,
                                 endPrePrcess - endReadingfiles,
                                 endIndexing - endPrePrcess};

            return times;

        }
        //Search All
        public TopDocs SearchAll (string querytext)
        {
            DateTime start = System.DateTime.Now;
            query = parserAll.Parse(querytext);
            DateTime endPre = System.DateTime.Now;

            TopDocs results = searcher.Search(query, 1000);
            DateTime endSearch = System.DateTime.Now;

            preprocessTime = endPre - start;
            searchTime = endSearch - endPre;

            return results;
        }

        //Meta Search
        public TopDocs SearchText(string querytext)
        {
            DateTime start = System.DateTime.Now;
            query = parserText.Parse(querytext);
            DateTime endPre = System.DateTime.Now;

            TopDocs results = searcher.Search(query, 1000);
            DateTime endSearch = System.DateTime.Now;

            preprocessTime = endPre - start;
            searchTime = endSearch - endPre;

            return results;
        }

        //Search Without Pre-processing
        public TopDocs SearchNoPreAll(string querytext)
        {
            DateTime start = System.DateTime.Now;
            query = parserAllNoPre.Parse(querytext);
            DateTime endPre = System.DateTime.Now;

            TopDocs results = searcher.Search(query, 1000);
            DateTime endSearch = System.DateTime.Now;

            preprocessTime = endPre - start;
            searchTime = endSearch - endPre;

            return results;
        }

        //Search titles
        public TopDocs SearchTitle(string querytext)
        {
            DateTime start = System.DateTime.Now;
            query = parserTitle.Parse(querytext);
            DateTime endPre = System.DateTime.Now;

            TopDocs results = searcher.Search(query, 1000);
            DateTime endSearch = System.DateTime.Now;

            preprocessTime = endPre - start;
            searchTime = endSearch - endPre;

            return results;
        }

        //Search Authors
        public TopDocs SearchAuthor(string querytext)
        {

            DateTime start = System.DateTime.Now;
            query = parserAuthor.Parse(querytext);
            DateTime endPre = System.DateTime.Now;

            TopDocs results = searcher.Search(query, 1000);
            DateTime endSearch = System.DateTime.Now;

            preprocessTime = endPre - start;
            searchTime = endSearch - endPre;

            return results;
        }

        //Search Biblighraphic
        public TopDocs SearchBiblo(string querytext)
        {

            DateTime start = System.DateTime.Now;
            query = parserBiblo.Parse(querytext);
            DateTime endPre = System.DateTime.Now;

            TopDocs results = searcher.Search(query, 1000);
            DateTime endSearch = System.DateTime.Now;

            preprocessTime = endPre - start;
            searchTime = endSearch - endPre;

            return results;
        }

        public void ImportWordnet()
        {
            var directory = System.IO.Directory.GetCurrentDirectory() + "\\wordnet\\";

            wordNet = new WordNetEngine();

            wordNet.LoadFromDirectory(directory);
        }

    }
}
