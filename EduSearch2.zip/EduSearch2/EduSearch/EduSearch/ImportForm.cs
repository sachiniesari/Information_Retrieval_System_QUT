﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EduSearch
{
    public partial class ImportForm : Form
    {
        public static SearchApp mySearchApp = new SearchApp();
        public ImportForm()
        {
            InitializeComponent();
        }

        private void ImportForm_Load(object sender, EventArgs e)
        {

        }

        private void buttonSaveIndex_Click(object sender, EventArgs e)
        {
            saveFileDialog1.ShowDialog();
            string indDir = saveFileDialog1.FileName;
            indexTextBox.Text = indDir;
        }

        private void buttonImport_Click(object sender, EventArgs e)
        {
            folderBrowserDialogImport.ShowDialog();
            string dataDir = folderBrowserDialogImport.SelectedPath;
            importTextBox.Text = dataDir;
        }

        private void buttonDone_Click(object sender, EventArgs e)
        {
            if (indexTextBox.Text == "")
            {
                System.Windows.Forms.MessageBox.Show("Please enter a location to save index files.");
            }
            if (importTextBox.Text == "")
            {
                System.Windows.Forms.MessageBox.Show("Please enter the path of colllection.");
            }
            if (indexTextBox.Text != "" && importTextBox.Text != "")
            {
                TimeSpan[] times = mySearchApp.Indexig(importTextBox.Text, indexTextBox.Text);

                mySearchApp.ImportWordnet();
                //var a = mySearchApp.wordNet.GetSynSets("do");
                //System.Windows.Forms.MessageBox.Show(a.ToString());

                //Show complete message
                System.Windows.Forms.MessageBox.Show("Indexing Done.\nReading Time: " + times[0] + 
                                                     "\nPre-Processing Time: " + times[1] +
                                                     "\nindexing Time: " + times[2]);

                //Close import form and open main form
                this.Hide();
                MainForm mainForm = new MainForm(mySearchApp);
                mainForm.ShowDialog();
                this.Close();
            }
        }
    }
}
