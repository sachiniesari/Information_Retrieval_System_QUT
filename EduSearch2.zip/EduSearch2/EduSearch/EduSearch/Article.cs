﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EduSearch
{
    public class Article
    {
        public string FileName { get; set; }
        public string DocID { get; set; }
        public string Title { get; set; }
        public string Author { get; set; }
        public string Biblo { get; set; }
        public string Text { get; set; }


        public Article(string fileName, string fileText)
        {
            PreProcess(fileName, fileText);
        }

        /// <summary>
        /// Split text to its sections using pre-defined tags
        /// </summary>
        /// <param name="fileText">The text</param>
        string[] SplitSections(string fileText)
        {
            string[] tags = { ".I", ".T", ".A", ".B", ".W" };
            string[] sections = fileText.Split(tags, StringSplitOptions.RemoveEmptyEntries);
            return sections;
        }

        public void PreProcess(string name, string text)
        {
            string[] sections = SplitSections(text);
            FileName = name;
            DocID = (sections[0].Replace("\n", String.Empty)).ToLower();
            Title = (sections[1].Replace("\n", String.Empty)).ToLower();
            Author = (sections[2].Replace("\n", String.Empty)).ToLower();
            Biblo = (sections[3].Replace("\n", String.Empty)).ToLower();
            string tempText = (sections[4].Replace("\n", String.Empty)).ToLower();

            //Remove title from text
            if (Title.Length < tempText.Length)
            {
                Text = tempText.Substring((Title.Length), tempText.Length - (Title.Length));
            }
            else
            {
                Text = tempText;
            }
        }
    }
}
